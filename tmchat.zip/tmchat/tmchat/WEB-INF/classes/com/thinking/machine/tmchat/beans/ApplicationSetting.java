package com.thinking.machine.tmchat.beans;
import java.io.*;
public class ApplicationSetting implements Serializable
{
public static final int FRIEND_REQUEST_NOTIFICATION=1;
public static final int FRIEND_REQUEST_ACCEPTED_NOTIFICATION=2;
public static final int UNFRIENDED_NOTIFICATION=3;
public static final int MESSAGE_NOTIFICATION=4;
}